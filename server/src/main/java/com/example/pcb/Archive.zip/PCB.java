package com.example.pcb;
// PCB.java (Strategy Interface)
public interface PCB {
    double getDefectRate(String stationName);

    String getType();
}