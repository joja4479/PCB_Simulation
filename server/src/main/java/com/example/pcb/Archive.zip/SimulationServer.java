package com.example.pcb;
// SimulationServer.java

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimulationServer {
    public static void main(String[] args) {
        SpringApplication.run(SimulationServer.class, args);
    }
}
